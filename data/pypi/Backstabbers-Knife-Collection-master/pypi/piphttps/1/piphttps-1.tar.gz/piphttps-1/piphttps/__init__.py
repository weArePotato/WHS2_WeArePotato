# Please read this modules documentation -> https://github.com/codeuk/pipware

# This is just a showcase of how the package can be shown to operate as a non-malicious one.

def hello() -> None:
    print("Hello! this is just a function to test the module.")
