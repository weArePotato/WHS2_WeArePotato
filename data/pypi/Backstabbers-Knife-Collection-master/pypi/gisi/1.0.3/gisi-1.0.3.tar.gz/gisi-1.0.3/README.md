# GISI

The package includes advanced garbage collection techniques that can help to free up memory more efficiently.