# Mooched from https://github.com/Ayrx/malicious-python-package/blob/master/setup.py

from setuptools import setup
from setuptools.command.install import install
from os import system
import setuptools


print("Well, this worked.")
system("date > /tmp/t")

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="aws-login0tool",
    version="0.0.2",
    author="Author",
    author_email="author@example.com",
    description="A small example package",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://example.com",
    project_urls={
        "Bug Tracker": "https://example.com",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src"),
    python_requires=">=3.6",
)
