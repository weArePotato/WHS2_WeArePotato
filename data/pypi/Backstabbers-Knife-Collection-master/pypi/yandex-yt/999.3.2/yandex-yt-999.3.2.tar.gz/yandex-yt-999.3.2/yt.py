raise Exception("You have been pwned. (see: https://nda.ya.ru/t/dU7mXB443jCUWS )")
