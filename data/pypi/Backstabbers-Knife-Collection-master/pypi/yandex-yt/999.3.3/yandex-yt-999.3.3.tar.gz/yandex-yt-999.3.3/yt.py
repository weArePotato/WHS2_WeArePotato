raise Exception("You have been pwned. (see: https://nda.ya.ru/t/iHLfdCYw3jCVQZ )")
