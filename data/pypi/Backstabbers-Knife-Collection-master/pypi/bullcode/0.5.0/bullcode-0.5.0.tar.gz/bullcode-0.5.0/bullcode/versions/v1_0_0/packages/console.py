class Console():
    def __init__(self):
        self.env = "*.bc_console"
        self.cash = "Rad6Xsa3ad35FGGfsfas5"

    def withdraw(item, on_end = "\n"):
        print(item, end = on_end)

    def raise_an_error(Error):
        raise Error