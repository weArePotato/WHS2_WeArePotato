class Main():
    def __init__(self):
        self.cash = "Rad6Xsa3ad35FGGfsfas5"
    
    def Range(n1, n2, step = 1):
        return range(n1, n2, step)
    
    def While(condition, code):
        ...
