def withdraw(element):
    print(element)