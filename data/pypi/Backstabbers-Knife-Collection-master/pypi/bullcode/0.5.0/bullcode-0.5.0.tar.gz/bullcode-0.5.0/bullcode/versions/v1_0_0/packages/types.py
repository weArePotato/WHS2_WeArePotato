class Types():
    def __init__(self):
        self.cash = "Rad6Xsa3ad35FGGfsfas5"
    
    def Integer(item):
        return int(item)

    def Float(item):
        return float(item)
    
    def String(item):
        return str(item)
    
    def List(*items):
        return list(items)
    
    def Dictionary(*items):
        return dict(items)

    def Tuple(*items):
        return tuple(items)

    def ByteArray(*items):
        return bytearray(items)  

    def Boolean(item):
        return bool(item)