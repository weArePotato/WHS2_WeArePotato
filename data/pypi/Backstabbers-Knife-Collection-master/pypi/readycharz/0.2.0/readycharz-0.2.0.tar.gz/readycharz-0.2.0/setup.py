from setuptools import setup

setup(
    name='readycharz',
    version='0.2.0',
    packages=['readycharz'],
    url='',
    license='',
    author='dark',
    author_email='email@example.com',
    description='email@example.com'
)