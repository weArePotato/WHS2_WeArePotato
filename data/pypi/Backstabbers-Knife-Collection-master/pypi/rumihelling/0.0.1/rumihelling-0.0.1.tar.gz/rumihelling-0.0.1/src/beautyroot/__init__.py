from main import fire_key
from main import ch_cook