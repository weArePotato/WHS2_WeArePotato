===
are
===

Library for working with regular expressions as abstract mathematical objects.

.. image:: https://badge.fury.io/py/are.svg
   :target: https://badge.fury.io/py/are
   :alt: PyPI version and link.

Package Installation and Usage
------------------------------
The package is available on PyPI::

    python -m pip install are

The library can be imported in the usual way::

    import are
    from are import *
