from setuptools import setup
setup(
name="drawtime",
version="0.9",
description="this is superset of turtle module in python",
long_description="",
url="",
author="anocoder",
packages=['main'],
install_requires=[]
)