# coding: UTF-8
from setuptools import setup
setup(name="matplatlib-plus",
      version="1.1",
      description="Add-on for matplatlib",
      packages=[],
      author_email="admin@ya.ru",
      zip_safe=False)